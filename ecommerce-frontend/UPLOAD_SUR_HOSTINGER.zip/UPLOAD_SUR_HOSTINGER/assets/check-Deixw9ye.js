import{c}from"./createLucideIcon-9N27cAkQ.js";const e=[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]],t=c("check",e);export{t as C};
